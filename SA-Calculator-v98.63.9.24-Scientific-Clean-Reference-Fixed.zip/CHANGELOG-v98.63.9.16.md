# v98.63.9.16

## Currency converter
- All 105 supported currency options are visible immediately when either currency selector opens.
- Currency search is optional and filters the complete list from the first typed character.
- Each option presents the region flag glyph, localized currency name, ISO code and region name.
- Selected currency cards explicitly show their flag glyph instead of suppressing it.

## Unit converter
- All units in the active category are visible immediately when either unit selector opens.
- Search is optional and filters the active category's complete unit list.
- Fixed the option-row grid: unit labels now occupy the full text column instead of the empty flag column.
- Preserved category-specific unit lists, selection, swap and conversion calculations.

## Shared picker UI
- Consistent panel geometry, search field, scroll area, option row sizing and selected state.
- Keyboard focus remains on the close control on open; the Android IME does not open until the user taps search.
- One-character and multi-character search both work without hiding the list until typing.
