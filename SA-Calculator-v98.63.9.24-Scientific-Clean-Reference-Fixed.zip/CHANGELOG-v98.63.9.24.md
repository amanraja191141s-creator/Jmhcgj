# Changelog — v98.63.9.24

## Scientific drawer visual cleanup
- Matched the supplied November 21 screen recording: scientific function keys are clean text controls on a soft pink drawer surface.
- Removed individual button borders, card-like backgrounds, shadows, and the small helper captions above function names.
- Kept the 4×4 function matrix, one-shot INV modifier, existing function tokens, and the underlying calculator display/keypad geometry.
- Removed the scientific display, toolbar, memory strip, and duplicate numeric keypad from the visible drawer surface so no extra text rows appear above or below the function matrix.
- Moved secondary controls (DEG/RAD, cursor, delete, clear, history, close, and memory controls) into the `+` panel so they remain available without cluttering the reference-matched surface.
- Kept the `+` control visually distinct and round; retained responsive touch targets and keyboard focus treatment.
- Updated app/PWA/Android workflow identity and service-worker cache namespace.

## Scope
This release changes the scientific drawer presentation and control placement. The calculator arithmetic/evaluation engine and existing function insertion tokens are preserved.
